Hallo! Sie lesen diesen Text, also haben sie die ReadMe schon gefunden. 

Schritt 1 zum Erfolgreichen Lösen eines Kriminalfalls ist geschafft!
Kommen wir zu weniger erfolgreichen Dingen: Bekannte Bugs, die wir leider nicht lösen konnten.
- Der Skill beendet leider nicht automatisch nach dem Lösen/nicht Lösen des Skills. 
- Einige Wörter (z.B. stop/goodbye) sollten im Spiel nicht verwendet werden, da dies Alexa-Codewörter sind und von Alexa, statt des Skills aufgefangen werden.
   -->Alternativ kann man diese Wörter natürlich deaktivieren.
- sollte der Skill noch aktiv sein, aber keine Antwort mehr kommen kann man häufig mit einem "leave" zurück kommen.
- Manchmal bricht der Skill einfach im Intro ab. Dieses Problem hatten wir auch in der Abschlusspräsentation. Bisher konnten wir den Grund nicht finden, 
   aber es hilft die WAR neu zu bilden und tomcat/ngrok neu zu starten. Danach sollte sich das Problem gelöst haben.

Wir haben eine WAR beigelegt, bei der es bei uns funktioniert hat.

Viel Spaß und Erfolg bei der Jagd nach dem Mörder von Lord Furbish.
