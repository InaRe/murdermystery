package com.amazon.customskill;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class RegExpTester {


	
	public static void main(String[] args) throws IOException {	
		int a= 7; //1=Raum, 2=Zeuge, 3=Solve, 4=Leave, 5=yesno, 6=tutorial, 7=watson
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		AlexaSkillSpeechlet ass = new AlexaSkillSpeechlet();
		while (true) {
			System.out.print("Pattern: ");
			String eingabe = br.readLine().trim();
			int z=ass.RecUI(eingabe, a);
			System.out.println("erkannt: "+z);
		}
	}










}
